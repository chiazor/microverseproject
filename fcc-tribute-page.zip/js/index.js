// coded by @ChaituVR
const projectName = 'tribute-page';
localStorage.setItem('example_project', 'Tribute Page');